import pytest
from calculate.calculator_program import calculate

def test_calculate_addition():
    assert calculate(1, 1, '+') == 2

def test_calculate_division():
    assert calculate(8, 2, '/') == 4

def test_calculate_subtraction():
    assert calculate(9, 6, '-') == 3

def test_calculate_division_by_zero():
    assert calculate(7, 0, '/') == "Деление на ноль невозможно."

def test_calculate_unknown_operation():
    assert calculate(5, 5, 'unknown') == "Неизвестная операция."



